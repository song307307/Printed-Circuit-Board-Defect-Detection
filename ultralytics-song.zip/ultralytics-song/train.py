import warnings, os
warnings.filterwarnings('ignore')
from ultralytics import YOLO
if __name__ == '__main__':
    model = YOLO('ultralytics/cfg/models/11/yolo11-C3k2-MutilScaleEdgeInformationEnhance.yaml')
    model.load('yolo11n.pt') # loading pretrain weights
    model.train(data='ultralytics/pcb.yaml',
                cache=False,
                imgsz=640,
                epochs=250,
                batch=32,
                close_mosaic=10,
                workers=0, 
                # device='0,1', 
                optimizer='SGD', 
                # patience=0, 
                # resume=True, 
                # amp=False, 
                # fraction=0.2,
                project='runs/train',
                name='yolo11-C3k2-MutilScaleEdgeInformationEnhance',
                )